<?php $__env->startSection('judul'); ?>
Data Pengarang
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box">
    <div class="box-header">
    <a href="<?php echo e(url('pengarang/add')); ?>"><button type="button" class="btn bg-green btn-flat margin">Add New</button></a>
    </div>
    <div class="box-body">
        <table id="data" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>No Pengarang</th>
                    <th>Lahir</th>
                    <th>Alamat</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- Menampilkan Data Anggota -->
                <?php $__currentLoopData = $pengarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsPenga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($rsPenga['kd_pengarang']); ?></td>
                    <td><?php echo e($rsPenga['nama_pengarang']); ?></td>                    
                    <td><?php echo e($rsPenga['tempat']." , ".$rsPenga['tgl_lahir']); ?></td>
                    <td><?php echo e($rsPenga['alamat']." ".$rsPenga['kota']); ?></td>
                    <td><?php echo e($rsPenga['email']); ?></td>
                    <td>
                        <a href="<?php echo e(url('pengarang/edit',$rsPenga['kd_pengarang'])); ?>"><button type="button" class="btn bg-yellow btn-flat"><i class="fa fa-pencil"></i></button></a>
                        <a href="<?php echo e(url('pengarang/delete',$rsPenga['kd_pengarang'])); ?>"><button type="button" class="btn bg-red btn-flat"><i class="fa fa-trash"></i></button></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>