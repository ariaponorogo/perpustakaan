<!-- REQUIRED JS SCRIPTS -->


<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset('component/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<!-- DataTables -->
<script src="<?php echo e(asset('component/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('component/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<!-- date-range-picker -->
<script src="<?php echo e(asset('component/moment/min/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('component/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
<!-- bootstrap datepicker -->
<script src="<?php echo e(asset('component/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- bootstrap color picker -->
<script src="<?php echo e(asset('component/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js')); ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo e(asset('component/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<!-- FastClick -->
<script src="<?php echo e(asset('component/fastclick/lib/fastclick.js')); ?>"></script>
<!-- Sweet Alert -->
<script src="<?php echo e(asset('component/sweetalert/sweetalert2.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('js/adminlte.min.js')); ?>"></script>
<!-- Custom JS -->
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
