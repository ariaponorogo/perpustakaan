<style>
      body{
        background-image:url('img/latar.jpg');
        background-position: center;
        background-size: cover;
        background-repeat: no-repeat;
      }
      form{
        margin: 100px auto;
        border: 1px solid rgba(201,217,207,0.3);
        padding: 20px 15px;
        max-width: 500px;
        background-color:#aab598;
      }
      form p{
        margin-bottom: 30px;
      }
  </style>

<?php $__env->startSection('content'); ?>
  </head>
  <body>
    

<!-- Default form login -->
<form id="formLogin" action="<?php echo e(route('login')); ?>" method="post">
<?php echo csrf_field(); ?>
      <div id="pesan">
        <?php
        if(isset($_GET['pesan'])){
          echo '<div class="alert alert-danger" role="alert">'.$_GET['pesan'].'</div>';
        }
        ?>
      </div>
<form class="text-center border border-light p-5">

    <p class ="h4 mb-4" style="color:white;"><strong>Sign in</strong></p>

    <!-- Email -->
    <input id="email" placeholder="Email" type="email" class="form-control mb-4<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
        <?php if($errors->has('email')): ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>

    <!-- Password -->
    <input id="password" placeholder="Password" type="password" class="form-control mb-4<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
    <?php if($errors->has('password')): ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('password')); ?></strong>
        </span>
    <?php endif; ?>

    <div class="d-flex justify-content-around">
        <div>
            <!-- Remember me -->
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="defaultLoginFormRemember">
                <label class="custom-control-label" for="defaultLoginFormRemember" style="color:white;">Remember me</label>
            </div>
        </div>
        <div>            
        </div>
    </div>

    <!-- Sign in button -->
    <button class="btn btn-info" type="submit" style="color:white; background-color:blue; border-color:#671b03;"><strong><?php echo e(__('Login')); ?></strong></button>

    <!-- Register -->
    <p class="not" style="color:white;">Not a member?
        <a href="<?php echo e(route('register')); ?>" style="color:white;"><strong>Register</strong></a>
    </p>

</form>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>