<?php $__env->startSection('judul'); ?>
Daftar Anggota
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ac-ang'); ?>
active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="box">
    <div class="box-header">
    <a href="<?php echo e(url('anggota/add')); ?>"><button type="button" class="btn bg-green btn-flat margin">Add New</button></a>
    </div>
    <div class="box-body">
        <table id="DT" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>No anggota</th>
                    <th>Nama Anggota</th>
                    <th>Lahir</th>
                    <th>Alamat</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <!--tampil data-->
            <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($row ['kd_anggota']); ?></td>
                    <td><?php echo e($row['no_anggota']); ?></td>
                    <td><?php echo e($row['nama']); ?></td>
                    <td><?php echo e($row ['tempat'].", ".$row['tgl_lahir']); ?></td>
                    <td><?php echo e($row['alamat'].", ".$row['kota']); ?></td>
                    <td><?php echo e($row['user_email']); ?></td>
                    <td>
                        <a href="<?php echo e(url('anggota/edit',$row['kd_anggota'])); ?>"><button type="button" class="btn bg-yellow btn-flat"><i class="fa fa-pencil"></i></button></a>
                        <a  href="anggota/delete/<?php echo e($row->kd_anggota); ?>"><button type="button" class="btn bg-red btn-flat"><i class="fa fa-trash"></i></button></a>    
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>