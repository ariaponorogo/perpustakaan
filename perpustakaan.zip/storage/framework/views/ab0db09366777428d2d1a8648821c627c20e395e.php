<?php $__env->startSection('judul'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subjudul'); ?>
Ini adalah Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<button onclick="pesan('top','error','Ini Adalah Pesan Error',1000)">KLIK SAYA</button>

<script>
$(document).ready(function(){
    pesan('button','success','Ini Adalah Pesan Success',1500);
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>